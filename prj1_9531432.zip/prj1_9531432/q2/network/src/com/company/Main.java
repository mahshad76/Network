package com.company;

import java.io.IOException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException {


        while (true) {
            System.out.println("enter your mode with s or c");
            Scanner scan = new Scanner(System.in);
            String mode = scan.next();
            if (mode.contains("s")) {
                server se = new server();
                se.run_s();
            }
            if (mode.contains("c")) {
                client cl = new client();
                cl.run_c();

            }
        }
    }
}
