package com.company;

import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;
import sun.nio.ch.DatagramSocketAdaptor;

import javax.xml.crypto.Data;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.ArrayList;
import java.util.Random;

public class server {
    public void run_s() throws IOException {
        Random rand = new Random();
        int p = (int) (2000 + Math.random() * 5000 + 1);
        DatagramSocket server = new DatagramSocket(p);
        MulticastSocket multi = new MulticastSocket(1234);
        InetAddress group = InetAddress.getByName("239.0.0.1");
        multi.joinGroup(group);
        byte[] d_pack = new byte[150];
        for (int i=0;i<150;i++){
            d_pack[i]=(byte)' ';
        }

        while (true) {
            DatagramPacket rcv_pack = new DatagramPacket(d_pack, d_pack.length);
            multi.receive(rcv_pack);


            InetAddress address = rcv_pack.getAddress();
            String rcv_msg = new String(rcv_pack.getData());
            int cl_port = Integer.parseInt(rcv_msg.substring(0, 5));

            //  System.out.println(cl_port);
            ArrayList<Character> fileName = new ArrayList<>();
            int v = 5;
            char[] chars = rcv_msg.toCharArray();
            while (chars[v] != '*' && v < 150) {
                fileName.add(chars[v]);
                v++;
            }
            StringBuilder builder = new StringBuilder(fileName.size());
            for (Character ch : fileName) {
                builder.append(ch);
            }


            String path = "C:\\requestedfiles\\"+builder;
            // System.out.println(path);
            File req_file = new File(path);
            if (req_file.exists()) {
                System.out.println("file exists");
                FileInputStream out = new FileInputStream(req_file);
                int offset = 0;
                byte[] pack2 = new byte[127];
                for (int j = 0; j < pack2.length; j++) {
                    pack2[j] = (byte) ' ';
                }
                //System.out.println();
                while (out.read(pack2) != -1) {
                    byte[] pack1 = new byte[128];
                    for (int j = 0; j < pack1.length; j = j + 1) {
                        pack1[j] = ' ';
                    }
                    String off = Integer.toBinaryString(offset);
                    int len = off.length();
                    String eightZeroes = "00000000";
                    if (len < 8)
                        off = eightZeroes.substring(0, 8 - len).concat(off);
                    else
                        off = off.substring(len - 8);
                    int sum = 0;

                    for (int i = 0; i < 8; i++) {
                        int b = Character.getNumericValue(off.charAt(i));
                        sum += b * (int) (Math.pow((double) 2, (double) (7 - i)));
                    }
                    byte b1 = (byte) sum;
                    pack1[0] = b1;
                    //   System.out.println(pack1[0]);
                    for (int i = 0; i < 127; i++) {
                        pack1[i + 1] = pack2[i];
                        // System.out.println(pack1[i + 1]);
                    }
                    String s = new String(pack1, 0, pack1.length, "UTF-8");
                    // System.out.println(s);
                    DatagramPacket send_packet = new DatagramPacket(pack1,
                            pack1.length, address, cl_port);
                    server.send(send_packet);
                    for (int i = 0; i < pack2.length; i++) {
                        pack2[i] = (byte) ' ';
                    }

                    offset++;

                }
                DatagramPacket send = new DatagramPacket("lastpack".getBytes(), "lastpack"
                        .getBytes().length, address, cl_port);
                server.send(send);
                break;

            } else {

                String s = "the file doesnt exist";
                System.out.println("file not exists");
                byte[] msg = s.getBytes();
                DatagramPacket sv = new DatagramPacket(msg, msg.length, address, cl_port);
                server.send(sv);
                break;
            }

        }
    }
}
