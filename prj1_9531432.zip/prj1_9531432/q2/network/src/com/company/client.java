package com.company;

import sun.nio.ch.DatagramSocketAdaptor;

import javax.xml.crypto.Data;
import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.Scanner;

public class client {
    public void run_c() throws IOException {
        System.out.println("File Request");
        Scanner scan = new Scanner(System.in);
        String filename = scan.next();
        String[] name_parts = filename.split("\\.");
        MulticastSocket mu = new MulticastSocket(1234);
        InetAddress group = InetAddress.getByName("239.0.0.1");
        mu.joinGroup(group);
        DatagramSocket client = new DatagramSocket();
        int port = client.getLocalPort();
        //  System.out.println(port);
        byte[] send_msg = (port + filename + "*").getBytes();

        // DatagramPacket send_pack = new DatagramPacket(send_msg, send_msg.length, InetAddress.
        //    getByName("239.0.0.1"), 1234);
        //  mu.send(send_pack);

        byte[] total = new byte[1000000000];
        for (int i = 0; i < total.length; i++) {
            total[i] = ' ';
        }
        while (true) {
            DatagramPacket send_pack = new DatagramPacket(send_msg, send_msg.length, InetAddress.
                    getByName("239.0.0.1"), 1234);

            mu.send(send_pack);

            byte[] rc = new byte[128];
            for (int i = 0; i < 128; i++) {
                rc[i] = (byte) ' ';
            }
            DatagramPacket recv = new DatagramPacket(rc, rc.length);
            client.receive(recv);

            // System.out.println("///////////////////");
            String response = new String(rc, 0, rc.length, "UTF-8");
            if (response.contains("exist")) {
                System.out.println("the file doesnt exist");
                break;
            } else {
                //  System.out.println(response);
                if (response.contains("lastpack")) {
                    break;
                    // break;
                } else {
                    // String sub = response.substring(0, 8);
                    // System.out.println(sub);
                    // System.out.println(rc[0]);
                    int offs = rc[0];
                    for (int i = 1; i < 128; i++) {
                        int j = (offs * 127) + (i - 1);
                        // System.out.println(j);
                        total[j] = rc[i];
                        // System.out.println(total[j]);
                    }

                    // System.out.println(total.toString());
                    // writer.write(total.toString());

                }

            }
            //System.out.println(response);
        }
        File file = new File("C:\\Users\\Mohammadreza Rahmani\\Desktop\\response.txt");
        FileOutputStream fop = new FileOutputStream(file);
        if (!file.exists()) {
            file.createNewFile();
        }
        fop.write(total);
        fop.flush();
        fop.close();

    }
}
