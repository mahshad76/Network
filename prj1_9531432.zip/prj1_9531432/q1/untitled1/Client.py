import socket

host = '127.0.0.1'
port = 1373
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as c:
    c.connect((host, port))
    while True:
        sentence = input('write operator with operations')
        c.sendall(sentence.encode())
        data = c.recv(1024)
        message = data.decode()
        print(message)