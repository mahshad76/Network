import socket
import math
import timeit

host = '127.0.0.1'
port = 1373
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind((host, port))
    s.listen()
    conn, addr = s.accept()
    while True:
        mess = conn.recv(1024).decode()
        list = mess.split('$')
        operator = list[1]
        if operator == 'Add':
            op1 = list[2]
            op2 = list[3]
            tic = timeit.default_timer()
            res = float(op1) + float(op2)
            toc = timeit.default_timer()
            time_elapsed = toc - tic
        if operator == 'Substract':
            op1 = list[2]
            op2 = list[3]
            tic = timeit.default_timer()
            res = float(op1) - float(op2)
            toc = timeit.default_timer()
            time_elapsed=toc-tic
        if operator == 'Multiply':
            op1 = list[2]
            op2 = list[3]
            tic=timeit.default_timer()
            res = float(op1) * float(op2)
            toc=timeit.default_timer()
            time_elapsed=toc-tic
        if operator == 'Divide':
            op1 = list[2]
            op2 = list[3]
            tic=timeit.default_timer()
            res = float(op1) / float(op2)
            toc=timeit.default_timer()
            time_elapsed=toc-tic
        if operator == 'Sin':
            op1 = list[2]
            tic=timeit.default_timer()
            res = math.sin(math.radians(float(op1)))
            toc=timeit.default_timer()
            time_elapsed=toc-tic
        if operator == 'Cos':
            op1 = list[2]
            tic=timeit.default_timer()
            res = math.cos(math.radians(float(op1)))
            toc=timeit.default_timer()
            time_elapsed=toc-tic
        if operator == 'Tan':
            op1 = list[2]
            tic=timeit.default_timer()
            res = math.tan(math.radians(float(op1)))
            toc=timeit.default_timer()
            time_elapsed=toc-tic
        if operator == 'Cot':
            op1 = list[2]
            tic=timeit.default_timer()
            res1 = math.cos(math.radians(float(op1)))
            res2 = math.sin(math.radians(float(op1)))
            res = res1 / res2
            toc=timeit.default_timer()
            time_elapsed=toc-tic
        result = '$' + str(res) + '$' + str(time_elapsed) + '$'
        conn.sendall(str(result).encode())
